// authRoutes.js placeholder for skillup/backend/routes/
