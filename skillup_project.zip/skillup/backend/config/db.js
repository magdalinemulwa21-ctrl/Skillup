// db.js placeholder for skillup/backend/config/
